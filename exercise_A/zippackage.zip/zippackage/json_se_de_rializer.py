import json
import collections
# import base64
import numpy as np
from assignment_five import FFBPNetwork, run_sin, run_iris
from assignmentOne_Two import NNData, load_XOR

"""To be included in our encoding dictionary:
    [x] "_features" <array[dtype]>
    [x] "_labels" <array[dtype]>
    [x] "_train_indices" <list> # No brainer
    [x] "_test_indices" <list> # No brainer
    [x] "_train_pool" <deque>
    [x] "_test_pool" <deque>
    [x] "_train_factor" <float> # No brainer
"""


class MultiTypeEncoder(json.JSONEncoder):
    """Extended Json Encoder hook.
    - We added handler for Set & bytes. """
    def default(self, o):
        if isinstance(o, collections.deque):
            return {"__deque__": list(o)}
        elif isinstance(o, np.ndarray):
            return {"__NDarray__": o.tolist()}
        elif isinstance(o, set):
            return {"__Set__": list(o)}
        elif isinstance(o, bytes):
            return {"__Bytes__": o.decode()}
        elif isinstance(o, NNData):
            return {"__NNData__": o.__dict__}
        else:
            json.JSONEncoder.default(self, o)


def multi_type_decoder(o):
    """Extended Json decoder hook."""
    if "__deque__" in o:
        return collections.deque(o["__deque__"])
    if "__NNData__" in o:
        dec_obj = o["__NNData__"]
        trainfactor = dec_obj["_train_factor"]
        train_indices = dec_obj["_train_indices"]
        test_indices = dec_obj["_test_indices"]
        train_pool = list(dec_obj["_train_pool"])
        test_pool = list(dec_obj["_test_pool"])
        features = np.array(dec_obj["_features"]["__NDarray__"])
        labels = np.array(dec_obj["_labels"]["__NDarray__"])
        ret_obj = NNData(features, labels, trainfactor)  # takes labels and features too as X & Y
        return ret_obj
    else:
        return o


def read_write(filename, data):
    """JSON Encoding and Decoding done here!
    pass in the object name you wish and the destination file name too.
    i.e xor_data data object, xor_data_encoded etc
    - this function gives that flexibility."""
    with open(filename, "w") as f:
        json.dump(data, f, indent=2, cls=MultiTypeEncoder)

    with open(filename, "r") as f:
        my_obj = json.load(f, object_hook=multi_type_decoder)
        print(type(my_obj))
        print(my_obj)


def main():
    """Comment out the dataset you wish to train out of the three...
    Otherwise you run the risk of running all of them at ago,
    which is not practical. """
    iris_data = run_iris()
    sin_data = run_sin()
    xor_data = load_XOR()
    # print(data2.__dict__)
    # print(data.__dict__)

    # 1. Train and Test Network For sin Dataset
    read_write("sin_decoded.txt", sin_data)
    network = FFBPNetwork(1, 1)
    network.add_hidden_layer(3)
    print("Train")
    network.train(sin_data, 1000, order=NNData.Order.RANDOM)
    print("----------------------------------------")
    print("Test")
    network.test(sin_data)

    # 2. Train and Test Network For Iris Datasets
    # read_write("iris_decoded.txt", iris_data)
    # network = FFBPNetwork(4, 3)
    # network.add_hidden_layer(3)
    # print("Train")
    # network.train(sin_data, 1000, order=NNData.Order.RANDOM)
    # print("----------------------------------------")
    # print("Test")
    # network.test(sin_data)

    # 3. Train and Test Network For XOR Dataset.
    # read_write("xor_decoded.txt", xor_data)
    # network = FFBPNetwork(1, 1)
    # network.add_hidden_layer(3)
    # print("Train")
    # network.train(xor_data, 1000, order=NNData.Order.RANDOM)
    # print("----------------------------------------")
    # print("Test")
    # network.test(xor_data,  order=NNData.Order.SEQUENTIAL)


if __name__ == "__main__":
    main()
